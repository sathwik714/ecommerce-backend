package com.hub.ecommerce.models.admin.entities.models;

public enum Clarity {
    IFtoVVS2,VS1toVS2,SI1toSI2,SI3toI1
}
