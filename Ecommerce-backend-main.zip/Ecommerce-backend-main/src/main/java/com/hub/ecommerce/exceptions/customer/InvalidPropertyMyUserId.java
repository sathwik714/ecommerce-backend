package com.hub.ecommerce.exceptions.customer;

public class InvalidPropertyMyUserId extends Exception{
    public InvalidPropertyMyUserId(String s){
        super(s);
    }
}