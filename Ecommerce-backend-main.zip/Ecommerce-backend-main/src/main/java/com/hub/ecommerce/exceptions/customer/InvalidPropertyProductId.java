package com.hub.ecommerce.exceptions.customer;

public class InvalidPropertyProductId extends Exception{
    public InvalidPropertyProductId(String s){
        super(s);
    }
}