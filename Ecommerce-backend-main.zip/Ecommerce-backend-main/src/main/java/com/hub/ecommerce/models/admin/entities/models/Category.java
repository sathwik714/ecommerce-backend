package com.hub.ecommerce.models.admin.entities.models;

public enum Category {
    FashionJewelry,FineJewelry,EngagementRings,Diamonds
}
