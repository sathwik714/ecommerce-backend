package com.hub.ecommerce.models.admin.entities.models;

public enum Metal {
    Platinum,YellowGold,RoseGold,WhiteGold
}
