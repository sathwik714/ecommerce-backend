package com.hub.ecommerce.models.admin.entities.models;

public enum NonCertDiamondName {
    WhiteRound,Baguette,Princess
}
