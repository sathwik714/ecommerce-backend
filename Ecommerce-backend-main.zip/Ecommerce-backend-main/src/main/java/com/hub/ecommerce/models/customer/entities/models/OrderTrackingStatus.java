package com.hub.ecommerce.models.customer.entities.models;

public enum OrderTrackingStatus {
    NA, Received, Packaging , Dispatched, Delivered
}
