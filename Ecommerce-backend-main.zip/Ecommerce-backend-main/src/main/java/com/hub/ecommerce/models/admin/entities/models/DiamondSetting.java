package com.hub.ecommerce.models.admin.entities.models;

public enum DiamondSetting {
    ProngSetting , MicroProng, PaveSetting, ChannelSetting, Invisible
}
