package com.hub.ecommerce.exceptions.auth;

public class InvalidAuthenticationProperty extends Exception{
    public InvalidAuthenticationProperty(String s){
        super(s);
    }
}
