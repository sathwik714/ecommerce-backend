package com.hub.ecommerce.models.admin.request;

import java.io.Serializable;

public class GetProductById implements Serializable {
    private String productId;
}
