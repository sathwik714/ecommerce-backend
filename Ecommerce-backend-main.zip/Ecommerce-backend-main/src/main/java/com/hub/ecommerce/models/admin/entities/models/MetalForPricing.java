package com.hub.ecommerce.models.admin.entities.models;

public enum MetalForPricing {
    Gold, Platinum
}
