package com.hub.ecommerce.models.admin.entities.models;

public enum Section {
    Rings,Earrings,Pendant,Necklace,Bracelet,Men,Women,Couple
}
