package com.hub.ecommerce.models.admin.entities.models;

public enum Purity {
    kt22,kt18,kt14,NA
}
