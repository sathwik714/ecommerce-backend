package com.hub.ecommerce.models.admin.entities.models;

public enum Color {
    DtoF, GtoI, JtoK, LtoM
}