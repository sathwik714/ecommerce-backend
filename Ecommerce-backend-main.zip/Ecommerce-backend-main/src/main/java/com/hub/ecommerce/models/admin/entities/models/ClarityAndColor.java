package com.hub.ecommerce.models.admin.entities.models;

public enum ClarityAndColor {
//    IFtoVVS2_DtoF,VS1toVS2_GtoI,SI1toSI2_JtoK,SI3toI1_LtoM;
    IFtoVVS2_DtoF, VS1toVS2_GtoI, SI1toSI2_JtoK, VVS1toVVS2_GtoI, VS1toVS2_JtoK, SI1toSI2_LtoM,
//    55  ,         53,             51,             49,             47,         45
}
