create table userss (
  id int,
  user_name varchar,
  password varchar,
  active boolean,
  roles varchar,
  primary key (id)
);

